import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 2162;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // component1Nr5 (9:1602)
        padding: EdgeInsets.fromLTRB(100*fem, 100*fem, 100*fem, 100*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          border: Border.all(color: Color(0xff171717)),
          borderRadius: BorderRadius.circular(5*fem),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            TextButton(
              // property1graph1fqB (9:1598)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 50*fem,
                height: 134*fem,
                child: Image.asset(
                  'assets/assets/images/property-1graph-1.png',
                  width: 50*fem,
                  height: 134*fem,
                ),
              ),
            ),
            SizedBox(
              width: 100*fem,
            ),
            TextButton(
              // property1graph2MT7 (9:1600)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 100*fem,
                height: 134*fem,
                child: Image.asset(
                  'assets/assets/images/property-1graph-2.png',
                  width: 100*fem,
                  height: 134*fem,
                ),
              ),
            ),
            SizedBox(
              width: 100*fem,
            ),
            TextButton(
              // property1graph3FHb (9:1597)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 150*fem,
                height: 134*fem,
                child: Image.asset(
                  'assets/assets/images/property-1graph-3.png',
                  width: 150*fem,
                  height: 134*fem,
                ),
              ),
            ),
            SizedBox(
              width: 100*fem,
            ),
            TextButton(
              // property1graph49Ny (9:1599)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 200*fem,
                height: 134*fem,
                child: Image.asset(
                  'assets/assets/images/property-1graph-4.png',
                  width: 200*fem,
                  height: 134*fem,
                ),
              ),
            ),
            SizedBox(
              width: 100*fem,
            ),
            TextButton(
              // property1graph5cXT (9:1601)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 250*fem,
                height: 134*fem,
                child: Image.asset(
                  'assets/assets/images/property-1graph-5.png',
                  width: 250*fem,
                  height: 134*fem,
                ),
              ),
            ),
            SizedBox(
              width: 100*fem,
            ),
            TextButton(
              // property1graph6Rzh (9:1596)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 300*fem,
                height: 134*fem,
                child: Image.asset(
                  'assets/assets/images/property-1graph-6.png',
                  width: 300*fem,
                  height: 134*fem,
                ),
              ),
            ),
            SizedBox(
              width: 100*fem,
            ),
            TextButton(
              // property1graph7JHo (9:1595)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: Container(
                width: 312*fem,
                height: 134*fem,
                child: Image.asset(
                  'assets/assets/images/property-1graph-7.png',
                  width: 312*fem,
                  height: 134*fem,
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}