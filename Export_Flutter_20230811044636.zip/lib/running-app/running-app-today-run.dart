import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // runningapptodayrunHiy (9:1615)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 38*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xff272244),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupy1ahzdP (QYPxhAjFfUoidwJ851y1Ah)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 8*fem),
              width: 379*fem,
              height: 700*fem,
              child: Stack(
                children: [
                  Positioned(
                    // group13K9s (25:76)
                    left: 0*fem,
                    top: 0*fem,
                    child: Container(
                      width: 375*fem,
                      height: 700*fem,
                      child: Stack(
                        children: [
                          Positioned(
                            // maskgroupE1w (25:9)
                            left: 0*fem,
                            top: 89*fem,
                            child: Align(
                              child: SizedBox(
                                width: 375*fem,
                                height: 470*fem,
                                child: Image.asset(
                                  'assets/running-app/images/mask-group-cTs.png',
                                  width: 375*fem,
                                  height: 470*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // rectangle76Kp5 (25:71)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 375*fem,
                                height: 700*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    gradient: LinearGradient (
                                      begin: Alignment(1, -0.425),
                                      end: Alignment(-1.077, -0.425),
                                      colors: <Color>[Color(0xff272244), Color(0x00272244), Color(0xff272244)],
                                      stops: <double>[0, 0.5, 1],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // rectangle77mRB (25:73)
                            left: 0*fem,
                            top: 0*fem,
                            child: Align(
                              child: SizedBox(
                                width: 375*fem,
                                height: 700*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    gradient: LinearGradient (
                                      begin: Alignment(0.085, 0.435),
                                      end: Alignment(0.085, -0.764),
                                      colors: <Color>[Color(0xff272244), Color(0x00272244), Color(0xff272244)],
                                      stops: <double>[0, 0.5, 1],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // group10EZf (13:1681)
                            left: 110*fem,
                            top: 39*fem,
                            child: Container(
                              width: 146*fem,
                              height: 40*fem,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // kingsroadACR (9:1653)
                                    margin: EdgeInsets.fromLTRB(10*fem, 0*fem, 0*fem, 6*fem),
                                    child: Text(
                                      'Kings Road',
                                      style: SafeGoogleFont (
                                        'Roboto',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w700,
                                        height: 1.1725*ffem/fem,
                                        color: Color(0xffffffff),
                                      ),
                                    ),
                                  ),
                                  Text(
                                    // railroadstreetnj2943TBX (9:1652)
                                    '6494	Railroad Street	NJ	2943',
                                    style: SafeGoogleFont (
                                      'Roboto',
                                      fontSize: 12*ffem,
                                      fontWeight: FontWeight.w300,
                                      height: 1.1725*ffem/fem,
                                      color: Color(0xffffffff),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Positioned(
                            // chevrondownArd (9:1654)
                            left: 32*fem,
                            top: 46*fem,
                            child: Align(
                              child: SizedBox(
                                width: 24*fem,
                                height: 24*fem,
                                child: TextButton(
                                  onPressed: () {},
                                  style: TextButton.styleFrom (
                                    padding: EdgeInsets.zero,
                                  ),
                                  child: Image.asset(
                                    'assets/running-app/images/chevron-down-nkH.png',
                                    width: 24*fem,
                                    height: 24*fem,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // chevrondownTqj (13:1701)
                            left: 314*fem,
                            top: 545*fem,
                            child: Align(
                              child: SizedBox(
                                width: 4*fem,
                                height: 8*fem,
                                child: Image.asset(
                                  'assets/running-app/images/chevron-down-YUh.png',
                                  width: 4*fem,
                                  height: 8*fem,
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // ellipse5PDb (9:1670)
                            left: 93*fem,
                            top: 612*fem,
                            child: Align(
                              child: SizedBox(
                                width: 15*fem,
                                height: 15*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(7.5*fem),
                                    color: Color(0xffc6409a),
                                    boxShadow: [
                                      BoxShadow(
                                        color: Color(0x66c6409a),
                                        offset: Offset(0*fem, 4*fem),
                                        blurRadius: 4*fem,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // GHP (13:1690)
                            left: 130*fem,
                            top: 596*fem,
                            child: Align(
                              child: SizedBox(
                                width: 120*fem,
                                height: 47*fem,
                                child: Text(
                                  '15:20',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 40*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 3.2*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // currentpace8aV (13:1691)
                            left: 113*fem,
                            top: 661*fem,
                            child: Align(
                              child: SizedBox(
                                width: 81*fem,
                                height: 15*fem,
                                child: Text(
                                  'Current Pace',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 0.96*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // km1uB (13:1692)
                            left: 199*fem,
                            top: 661*fem,
                            child: Align(
                              child: SizedBox(
                                width: 54*fem,
                                height: 15*fem,
                                child: Text(
                                  '6:10/Km',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 0.96*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // kmujf (9:1657)
                            left: 32*fem,
                            top: 202*fem,
                            child: Align(
                              child: SizedBox(
                                width: 55*fem,
                                height: 18*fem,
                                child: Text(
                                  '5.4 Km',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 1.2*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // kcal1nh (13:1686)
                            left: 32*fem,
                            top: 287*fem,
                            child: Align(
                              child: SizedBox(
                                width: 68*fem,
                                height: 18*fem,
                                child: Text(
                                  '234 Kcal',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 1.2*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // bpmKYV (13:1688)
                            left: 32*fem,
                            top: 373*fem,
                            child: Align(
                              child: SizedBox(
                                width: 69*fem,
                                height: 18*fem,
                                child: Text(
                                  '130 Bpm',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 15*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 1.2*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // distance2C1 (13:1685)
                            left: 32*fem,
                            top: 224*fem,
                            child: Align(
                              child: SizedBox(
                                width: 50*fem,
                                height: 15*fem,
                                child: Text(
                                  'Distance',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 0.36*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // caloriesWcy (13:1687)
                            left: 32*fem,
                            top: 309*fem,
                            child: Align(
                              child: SizedBox(
                                width: 47*fem,
                                height: 15*fem,
                                child: Text(
                                  'Calories',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 0.36*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // heartrate1Jq (13:1689)
                            left: 32*fem,
                            top: 395*fem,
                            child: Align(
                              child: SizedBox(
                                width: 61*fem,
                                height: 15*fem,
                                child: Text(
                                  'Heart Rate',
                                  style: SafeGoogleFont (
                                    'Roboto',
                                    fontSize: 12*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1725*ffem/fem,
                                    letterSpacing: 0.36*fem,
                                    color: Color(0xffffffff),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            // rectangle22WmP (13:1703)
                            left: 149*fem,
                            top: 545*fem,
                            child: Align(
                              child: SizedBox(
                                width: 70*fem,
                                height: 8*fem,
                                child: Container(
                                  decoration: BoxDecoration (
                                    borderRadius: BorderRadius.circular(10*fem),
                                    color: Color(0xff0b0430),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    // vector62jj (25:68)
                    left: 124.2020263672*fem,
                    top: 137.8306884766*fem,
                    child: Align(
                      child: SizedBox(
                        width: 254.8*fem,
                        height: 328.18*fem,
                        child: Image.asset(
                          'assets/running-app/images/vector-6.png',
                          width: 254.8*fem,
                          height: 328.18*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // component69ZT (25:278)
                    left: 167*fem,
                    top: 154*fem,
                    child: Align(
                      child: SizedBox(
                        width: 100*fem,
                        height: 100*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: Image.asset(
                            'assets/running-app/images/component-6-fkM.png',
                            width: 100*fem,
                            height: 100*fem,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroup15453Pw (QYPyEVAQN28PjAioBc1545)
              margin: EdgeInsets.fromLTRB(82*fem, 0*fem, 142*fem, 0*fem),
              width: double.infinity,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // rectangle21AjT (13:1700)
                    margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 44*fem, 0*fem),
                    width: 17*fem,
                    height: 17*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                    ),
                  ),
                  Container(
                    // group11gxh (13:1699)
                    width: 90*fem,
                    height: 90*fem,
                    child: Image.asset(
                      'assets/running-app/images/group-11.png',
                      width: 90*fem,
                      height: 90*fem,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}